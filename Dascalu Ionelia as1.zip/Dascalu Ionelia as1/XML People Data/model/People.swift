//
//  People.swift
//  XML People Data
//
//  Created by Sabin Tabirca on 24/03/2023.
// https://pastebin.com/HGw5YgYy

import Foundation

class People{
    
    var peopleData : [Person]!
    
    init(name:String){
        
        let xmlParser = XMLPeopleParser(name: name)
        xmlParser.parsing()
        self.peopleData = xmlParser.peopleData
        
    }
    
    func getPerson(index:Int)->Person{
        return self.peopleData[index]
    }
    
    func getCount()->Int{
        return self.peopleData.count
    }
}
