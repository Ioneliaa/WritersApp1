//
//  Person.swift
//  XML People Data
//
//  Created by Sabin Tabirca on 24/03/2023.
//https://pastebin.com/5ZsVrznx

import Foundation

class Person{
    var name, description, phone, email, image, urlaa : String!
    
    init(name: String!, description: String!, phone: String!, email: String!, image: String!, urlaa:String!) {
        self.name = name
        self.description = description
        self.phone = phone
        self.email = email
        self.image = image
        self.urlaa = urlaa
    }
}
