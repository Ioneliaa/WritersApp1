//
//  XMLPeopleParser.swift
//  XML People Data
//
//  Created by Sabin Tabirca on 24/03/2023.
// https://pastebin.com/8BawFyWe

import Foundation

class XMLPeopleParser:NSObject, XMLParserDelegate{
    
    var name : String
    init(name:String){self.name = name}
    
    // tmp vars for parsed data
    var pName, pDescription, pPhone, pEmail, pImage, pUrlaa:String!
    
    // vars to spy
    var elementId = -1
    var passData  = false
    
    // vars for data
    var peopleData = [Person]()
    var personData : Person!
    
    // parser
    var parser : XMLParser!
    
    let tags = ["name", "description", "phone", "email", "image", "urlaa"]
    
    // delegate methods for parsing
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        
        // set the spy vars based on elementName
        if tags.contains(elementName){
            passData = true
            elementId = tags.firstIndex(of: elementName)!
        }
        
    }
    
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        // place string to the right pVars
        switch elementId{
            case 0 : pName    = string
            case 1 : pDescription = string
            case 2 : pPhone   = string
            case 3 : pEmail   = string
            case 4 : pImage   = string
            case 5 : pUrlaa   = string
            default: break
        }
    }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        // reset the spys
        passData  = false; elementId = -1
        
        // if person then make an object for peopleData
        if elementName == "person"{
            personData = Person(name: pName,
                                description: pDescription, phone: pPhone, email: pEmail, image: pImage, urlaa: pUrlaa)
            peopleData.append(personData)
        }
    }
    
    func parsing(){
        // get the file
        let bundleUrl = Bundle.main.bundleURL
        let fileUrl   = URL(string: self.name, relativeTo: bundleUrl)
        
        // make the parser
        parser = XMLParser(contentsOf: fileUrl!)
        
        // parse
        parser.delegate = self
        parser.parse()
    }
    
}
