//
//  DetailSecondViewController.swift
//  XML People Data
//
//  Created by Dascalu Ionelia on 30.04.2023.
//

import UIKit

class DetailSecondViewController: UIViewController {

    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var labelEmail: UILabel!
    
    @IBAction func moreInfo(_ sender: Any) {
       
    }
    var img = UIImage()
    var name = ""
    var email = ""
    var descr: String = ""
    var urlaa: String = ""
    override func viewDidLoad() {
        super.viewDidLoad()

        labelName.text = name
        imgView.image = img
        labelEmail.text = email
        // Do any additional setup after loading the view.
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "segue1"{
           // Get the new view controller using segue.destination.
            let destinationController = segue.destination as! DetailThirdViewController
        // Pass the selected object to the new view controller.
            destinationController.text = self.descr
            
        }
        
        if segue.identifier == "segue2"{
           // Get the new view controller using segue.destination.
            let destinationController = segue.destination as! WebViewController
        // Pass the selected object to the new view controller.
            destinationController.urlaa = self.urlaa
            
        }
        
    }

    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
