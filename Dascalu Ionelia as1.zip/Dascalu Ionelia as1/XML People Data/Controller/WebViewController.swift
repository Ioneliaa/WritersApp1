//
//  WebViewController.swift
//  XML People Data
//
//  Created by Dascalu Ionelia on 18.05.2023.
//

import UIKit
import WebKit

// UIWebView is no longer suported since 2021 so i decided to implement mi web view like this.

class WebViewController: UIViewController {

    let webView = WKWebView()
    var urlaa = "https://en.wikipedia.org/wiki/List_of_Romanian_writers"
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        view.addSubview(webView)
        guard let url = URL(string: urlaa) else {
            return
        }
        webView.load(URLRequest(url: url))
        // Do any additional setup after loading the view.
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        webView.frame = view.bounds
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
